/* ==========================================================================
   GAMER STORE 3D - Global App Controller, Card Tilt Engine & Audio Synth
   ========================================================================== */

class GamerStoreApp {
  constructor() {
    this.soundMuted = false;
    this.audioCtx = null;
    this.cart = this.loadCart();

    this.initNavbar();
    this.initCursor();
    this.initParticleBackground();
    this.initAudioSynth();
    this.init3DCardTiltEngine();
    this.initGSAPAnimations();
    this.updateCartBadge();
  }

  // --- 1. LOCAL STORAGE CART MANAGEMENT ---
  loadCart() {
    try {
      const saved = localStorage.getItem('aetheria_cart');
      return saved ? JSON.parse(saved) : [
        { id: 'headphones-1', name: 'AETHERIA Spatial X1', price: 399, qty: 1, image: 'assets/images/headphones.jpg' }
      ];
    } catch (e) {
      return [];
    }
  }

  saveCart() {
    localStorage.setItem('aetheria_cart', JSON.stringify(this.cart));
    this.updateCartBadge();
  }

  addToCart(product) {
    const existing = this.cart.find(item => item.id === product.id);
    if (existing) {
      existing.qty += 1;
    } else {
      this.cart.push({
        id: product.id,
        name: product.name,
        price: product.price,
        qty: 1,
        image: product.image || 'assets/images/headphones.jpg'
      });
    }
    this.saveCart();
    this.playAudio('cartAdd');
    this.showToast(`Added "${product.name}" to your cart!`);
    window.dispatchEvent(new CustomEvent('cartUpdated'));
  }

  updateCartBadge() {
    const badges = document.querySelectorAll('.cart-badge');
    const totalCount = this.cart.reduce((sum, item) => sum + item.qty, 0);
    badges.forEach(b => {
      b.textContent = totalCount;
      b.style.display = totalCount > 0 ? 'flex' : 'none';
    });
  }

  // --- 2. 3D MAGNETIC CARD TILT ENGINE ---
  init3DCardTiltEngine() {
    const attachTilt = () => {
      const cards = document.querySelectorAll('.glass-card-tilt, .product-card, .glass-card-shimmer');
      cards.forEach(card => {
        if (card.dataset.tiltInitialized) return;
        card.dataset.tiltInitialized = 'true';

        // Insert Glare Element
        if (!card.querySelector('.card-glare')) {
          const glare = document.createElement('div');
          glare.className = 'card-glare';
          card.appendChild(glare);
        }

        card.addEventListener('mousemove', (e) => {
          const rect = card.getBoundingClientRect();
          const x = e.clientX - rect.left;
          const y = e.clientY - rect.top;

          const centerX = rect.width / 2;
          const centerY = rect.height / 2;

          const rotateX = ((y - centerY) / centerY) * -12; // max 12 deg tilt
          const rotateY = ((x - centerX) / centerX) * 12;

          card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.03)`;

          // Glare position
          const glare = card.querySelector('.card-glare');
          if (glare) {
            glare.style.background = `radial-gradient(circle at ${x}px ${y}px, rgba(0, 243, 255, 0.25) 0%, transparent 70%)`;
          }
        });

        card.addEventListener('mouseleave', () => {
          card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)';
        });
      });
    };

    attachTilt();
    // Re-attach when DOM updates dynamically (e.g. catalog filter)
    const observer = new MutationObserver(attachTilt);
    const grid = document.getElementById('catalog-products-grid');
    if (grid) observer.observe(grid, { childList: true });
  }

  // --- 3. GSAP SCROLL & ENTRANCE ANIMATIONS ---
  initGSAPAnimations() {
    if (typeof gsap === 'undefined') return;

    gsap.from('.hero-section h1, .hero-section p, .hero-section .btn-cyber', {
      opacity: 0,
      y: 40,
      duration: 1,
      stagger: 0.15,
      ease: 'power3.out'
    });

    gsap.from('.canvas-viewport-container', {
      opacity: 0,
      scale: 0.9,
      duration: 1.2,
      delay: 0.2,
      ease: 'power3.out'
    });
  }

  // --- 4. WEB AUDIO SYNTHESIZER ---
  initAudioSynth() {
    const audioBtn = document.getElementById('audio-toggle-btn');
    if (audioBtn) {
      audioBtn.addEventListener('click', () => {
        this.soundMuted = !this.soundMuted;
        audioBtn.innerHTML = this.soundMuted ? '🔇' : '🔊';
        this.showToast(this.soundMuted ? 'Audio Muted' : 'Audio Enabled');
        if (!this.soundMuted) this.playAudio('click');
      });
    }

    document.addEventListener('click', (e) => {
      if (e.target.closest('button, .btn-cyber, .nav-link, .cart-icon-btn, .hud-btn')) {
        this.playAudio('click');
      }
    });
  }

  playAudio(type) {
    if (this.soundMuted) return;
    try {
      if (!this.audioCtx) {
        this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }
      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }

      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();
      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      const now = this.audioCtx.currentTime;

      if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(850, now);
        osc.frequency.exponentialRampToValueAtTime(320, now + 0.05);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
        osc.start(now);
        osc.stop(now + 0.05);
      } else if (type === 'cartAdd') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        osc.start(now);
        osc.stop(now + 0.2);
      } else if (type === 'success') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, now);
        osc.frequency.setValueAtTime(659.25, now + 0.1);
        osc.frequency.setValueAtTime(783.99, now + 0.2);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
        osc.start(now);
        osc.stop(now + 0.4);
      }
    } catch (e) {
      console.warn('Audio error', e);
    }
  }

  // --- 5. STICKY NAVBAR & MOBILE MENU ---
  initNavbar() {
    const nav = document.querySelector('.navbar');
    if (!nav) return;
    window.addEventListener('scroll', () => {
      if (window.scrollY > 30) {
        nav.classList.add('scrolled');
      } else {
        nav.classList.remove('scrolled');
      }
    });

    const mobileToggle = document.querySelector('.mobile-nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (mobileToggle && navLinks) {
      mobileToggle.addEventListener('click', () => {
        navLinks.classList.toggle('open');
        mobileToggle.textContent = navLinks.classList.contains('open') ? '✕' : '☰';
      });
      // Close mobile nav on link click
      navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
          navLinks.classList.remove('open');
          mobileToggle.textContent = '☰';
        });
      });
    }
  }

  // --- 6. MAGNETIC CURSOR ---
  initCursor() {
    const cursor = document.querySelector('.custom-cursor');
    const follower = document.querySelector('.custom-cursor-follower');
    if (!cursor || !follower) return;

    let posX = 0, posY = 0, mouseX = 0, mouseY = 0;

    document.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      cursor.style.left = `${mouseX}px`;
      cursor.style.top = `${mouseY}px`;
    });

    const render = () => {
      posX += (mouseX - posX) * 0.15;
      posY += (mouseY - posY) * 0.15;
      follower.style.left = `${posX}px`;
      follower.style.top = `${posY}px`;
      requestAnimationFrame(render);
    };
    render();
  }

  // --- 7. PARTICLE STARFIELD CANVAS ---
  initParticleBackground() {
    const canvas = document.getElementById('bg-particles-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    });

    const particles = [];
    const count = Math.min(80, Math.floor(width / 15));

    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        radius: Math.random() * 1.5 + 0.5,
        alpha: Math.random() * 0.5 + 0.2
      });
    }

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 243, 255, ${p.alpha})`;
        ctx.fill();
      });

      requestAnimationFrame(draw);
    };

    draw();
  }

  // --- 8. TOAST NOTIFICATIONS ---
  showToast(message) {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span>🎮</span> ${message}`;

    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }
}

// Global instance
window.aetheriaApp = new GamerStoreApp();
