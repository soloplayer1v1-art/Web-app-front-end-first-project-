/* ==========================================================================
   AETHERIA 3D - Interactive Product Configurator Controller
   ========================================================================== */

class ConfiguratorController {
  constructor() {
    this.productId = this.getProductIdFromUrl() || 'headphones-x1';
    this.product = AETHERIA_PRODUCTS.find(p => p.id === this.productId) || AETHERIA_PRODUCTS[0];
    this.engine = null;
    this.quantity = 1;

    this.initUI();
    this.init3DScene();
  }

  getProductIdFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get('id');
  }

  initUI() {
    // Populate text details
    document.getElementById('config-product-name').textContent = this.product.name;
    document.getElementById('config-product-price').textContent = `$${this.product.price}`;
    document.getElementById('config-product-desc').textContent = this.product.description;

    // Populate Tech Specs
    const specsList = document.getElementById('config-specs-list');
    if (specsList && this.product.specs) {
      specsList.innerHTML = Object.entries(this.product.specs).map(([key, val]) => `
        <div style="display: flex; justify-content: space-between; padding: 0.75rem 0; border-bottom: 1px solid rgba(255,255,255,0.08); font-size: 0.9rem;">
          <span style="color: var(--text-muted);">${key}</span>
          <strong style="color: var(--primary-cyan);">${val}</strong>
        </div>
      `).join('');
    }

    // Color Swatches Listener
    const swatches = document.querySelectorAll('.color-swatch');
    swatches.forEach(swatch => {
      swatch.addEventListener('click', () => {
        swatches.forEach(s => s.classList.remove('active'));
        swatch.classList.add('active');
        const colorHex = parseInt(swatch.dataset.color.replace('#', '0x'), 16);
        if (this.engine) this.engine.setColor(colorHex);
      });
    });

    // Explode View Button
    const explodeBtn = document.getElementById('hud-explode-btn');
    if (explodeBtn) {
      let exploded = false;
      explodeBtn.addEventListener('click', () => {
        exploded = !exploded;
        explodeBtn.classList.toggle('active', exploded);
        if (this.engine) this.engine.toggleExplode(exploded);
      });
    }

    // Wireframe Mode Button
    const wireframeBtn = document.getElementById('hud-wireframe-btn');
    if (wireframeBtn) {
      let wf = false;
      wireframeBtn.addEventListener('click', () => {
        wf = !wf;
        wireframeBtn.classList.toggle('active', wf);
        if (this.engine) this.engine.toggleWireframe(wf);
      });
    }

    // Auto-Rotate Button
    const rotateBtn = document.getElementById('hud-rotate-btn');
    if (rotateBtn) {
      rotateBtn.addEventListener('click', () => {
        if (this.engine && this.engine.controls) {
          this.engine.controls.autoRotate = !this.engine.controls.autoRotate;
          rotateBtn.classList.toggle('active', this.engine.controls.autoRotate);
        }
      });
    }

    // Quantity Selector
    const qtyMinus = document.getElementById('qty-minus');
    const qtyPlus = document.getElementById('qty-plus');
    const qtyValue = document.getElementById('qty-value');

    if (qtyMinus && qtyPlus && qtyValue) {
      qtyMinus.addEventListener('click', () => {
        if (this.quantity > 1) {
          this.quantity--;
          qtyValue.textContent = this.quantity;
        }
      });
      qtyPlus.addEventListener('click', () => {
        this.quantity++;
        qtyValue.textContent = this.quantity;
      });
    }

    // Add to Cart Button
    const addToCartBtn = document.getElementById('config-add-cart-btn');
    if (addToCartBtn) {
      addToCartBtn.addEventListener('click', () => {
        if (window.aetheriaApp) {
          for (let i = 0; i < this.quantity; i++) {
            window.aetheriaApp.addToCart(this.product);
          }
        }
      });
    }
  }

  init3DScene() {
    const canvas = document.getElementById('configurator-canvas');
    if (canvas && window.Aetheria3DEngine) {
      this.engine = new window.Aetheria3DEngine('configurator-canvas', {
        modelType: this.product.modelType,
        cameraZ: 4.8,
        autoRotate: true
      });
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('configurator-canvas')) {
    window.configuratorController = new ConfiguratorController();
  }
});
