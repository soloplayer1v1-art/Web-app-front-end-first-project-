/* ==========================================================================
   AETHERIA 3D - Cart Drawer & Checkout Controller
   ========================================================================== */

class CheckoutController {
  constructor() {
    this.appliedDiscount = 0; // percentage
    this.couponCode = '';

    this.initCartDrawer();
    this.initCheckoutPage();
  }

  // --- 1. CART DRAWER TOGGLE & RENDER ---
  initCartDrawer() {
    this.drawer = document.getElementById('cart-drawer');
    this.overlay = document.getElementById('cart-drawer-overlay');
    const cartBtns = document.querySelectorAll('.cart-icon-btn');
    const closeBtns = document.querySelectorAll('.close-cart-drawer');

    cartBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openDrawer();
      });
    });

    closeBtns.forEach(btn => {
      btn.addEventListener('click', () => this.closeDrawer());
    });

    if (this.overlay) {
      this.overlay.addEventListener('click', () => this.closeDrawer());
    }

    window.addEventListener('cartUpdated', () => this.renderDrawer());
    this.renderDrawer();
  }

  openDrawer() {
    if (this.drawer) this.drawer.classList.add('open');
    if (this.overlay) this.overlay.classList.add('open');
    this.renderDrawer();
  }

  closeDrawer() {
    if (this.drawer) this.drawer.classList.remove('open');
    if (this.overlay) this.overlay.classList.remove('open');
  }

  renderDrawer() {
    const body = document.getElementById('cart-drawer-body');
    const subtotalEl = document.getElementById('cart-drawer-subtotal');
    if (!body || !window.aetheriaApp) return;

    const cart = window.aetheriaApp.cart;

    if (cart.length === 0) {
      body.innerHTML = `
        <div style="text-align: center; margin-top: 4rem; color: var(--text-muted);">
          <div style="font-size: 3rem; margin-bottom: 1rem;">🛒</div>
          <p>Your Holographic Cart is empty.</p>
          <a href="catalog.html" class="btn-cyber btn-cyber-secondary" style="margin-top: 1.5rem; display: inline-block;">Browse Gear</a>
        </div>
      `;
      if (subtotalEl) subtotalEl.textContent = '$0';
      return;
    }

    let subtotal = 0;
    body.innerHTML = cart.map(item => {
      const itemTotal = item.price * item.qty;
      subtotal += itemTotal;
      return `
        <div class="cart-item">
          <img src="${item.image}" alt="${item.name}" class="cart-item-img" />
          <div class="cart-item-info">
            <div class="cart-item-title">${item.name}</div>
            <div class="cart-item-price">$${item.price}</div>
            <div class="cart-item-qty">
              <button class="qty-btn" onclick="window.checkoutController.updateQty('${item.id}', -1)">-</button>
              <span style="font-size: 0.85rem; font-weight: 700;">${item.qty}</span>
              <button class="qty-btn" onclick="window.checkoutController.updateQty('${item.id}', 1)">+</button>
            </div>
          </div>
          <button class="close-btn" onclick="window.checkoutController.removeItem('${item.id}')" title="Remove">✕</button>
        </div>
      `;
    }).join('');

    if (subtotalEl) subtotalEl.textContent = `$${subtotal.toLocaleString()}`;
  }

  updateQty(itemId, change) {
    const item = window.aetheriaApp.cart.find(i => i.id === itemId);
    if (item) {
      item.qty += change;
      if (item.qty <= 0) {
        this.removeItem(itemId);
      } else {
        window.aetheriaApp.saveCart();
        this.renderDrawer();
        this.renderCheckoutSummary();
      }
    }
  }

  removeItem(itemId) {
    window.aetheriaApp.cart = window.aetheriaApp.cart.filter(i => i.id !== itemId);
    window.aetheriaApp.saveCart();
    this.renderDrawer();
    this.renderCheckoutSummary();
  }

  // --- 2. CHECKOUT PAGE LOGIC ---
  initCheckoutPage() {
    const checkoutContainer = document.getElementById('checkout-page-container');
    if (!checkoutContainer) return;

    this.renderCheckoutSummary();
    this.initCreditCardFlip();
    this.initCouponCode();
    this.initFormSubmit();
  }

  renderCheckoutSummary() {
    const itemsList = document.getElementById('checkout-items-list');
    const subtotalEl = document.getElementById('checkout-subtotal');
    const discountEl = document.getElementById('checkout-discount');
    const totalEl = document.getElementById('checkout-total');

    if (!itemsList || !window.aetheriaApp) return;

    const cart = window.aetheriaApp.cart;
    if (cart.length === 0) {
      itemsList.innerHTML = `<p style="color: var(--text-muted); text-align: center; padding: 2rem;">No items in checkout.</p>`;
      if (subtotalEl) subtotalEl.textContent = '$0';
      if (totalEl) totalEl.textContent = '$0';
      return;
    }

    let subtotal = 0;
    itemsList.innerHTML = cart.map(item => {
      subtotal += item.price * item.qty;
      return `
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.75rem 0; border-bottom: 1px solid rgba(255,255,255,0.06);">
          <div>
            <div style="font-weight: 600; font-size: 0.9rem;">${item.name}</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">Qty: ${item.qty} × $${item.price}</div>
          </div>
          <div style="font-family: var(--font-heading); color: var(--primary-cyan); font-size: 0.95rem;">
            $${item.price * item.qty}
          </div>
        </div>
      `;
    }).join('');

    const discountAmount = Math.round((subtotal * this.appliedDiscount) / 100);
    const total = subtotal - discountAmount;

    if (subtotalEl) subtotalEl.textContent = `$${subtotal.toLocaleString()}`;
    if (discountEl) discountEl.textContent = `-$${discountAmount.toLocaleString()}`;
    if (totalEl) totalEl.textContent = `$${total.toLocaleString()}`;
  }

  initCreditCardFlip() {
    const cardInner = document.getElementById('credit-card-inner');
    const cardNumInput = document.getElementById('card-number-input');
    const cardNameInput = document.getElementById('card-name-input');
    const cardExpInput = document.getElementById('card-exp-input');
    const cardCvvInput = document.getElementById('card-cvv-input');

    const cardNumDisplay = document.getElementById('card-number-display');
    const cardNameDisplay = document.getElementById('card-name-display');
    const cardExpDisplay = document.getElementById('card-exp-display');
    const cardCvvDisplay = document.getElementById('card-cvv-display');

    if (!cardInner) return;

    if (cardNumInput && cardNumDisplay) {
      cardNumInput.addEventListener('input', (e) => {
        let val = e.target.value.replace(/\D/g, '').substring(0, 16);
        val = val.replace(/(.{4})/g, '$1 ').trim();
        e.target.value = val;
        cardNumDisplay.textContent = val || '•••• •••• •••• ••••';
      });
    }

    if (cardNameInput && cardNameDisplay) {
      cardNameInput.addEventListener('input', (e) => {
        cardNameDisplay.textContent = e.target.value.toUpperCase() || 'CYBER CITIZEN';
      });
    }

    if (cardExpInput && cardExpDisplay) {
      cardExpInput.addEventListener('input', (e) => {
        let val = e.target.value.replace(/\D/g, '').substring(0, 4);
        if (val.length >= 2) val = val.substring(0, 2) + '/' + val.substring(2);
        e.target.value = val;
        cardExpDisplay.textContent = val || 'MM/YY';
      });
    }

    if (cardCvvInput && cardCvvDisplay) {
      cardCvvInput.addEventListener('focus', () => {
        cardInner.classList.add('flipped');
      });
      cardCvvInput.addEventListener('blur', () => {
        cardInner.classList.remove('flipped');
      });
      cardCvvInput.addEventListener('input', (e) => {
        cardCvvDisplay.textContent = e.target.value || '•••';
      });
    }
  }

  initCouponCode() {
    const applyBtn = document.getElementById('apply-coupon-btn');
    const input = document.getElementById('coupon-input');
    if (applyBtn && input) {
      applyBtn.addEventListener('click', () => {
        const code = input.value.trim().toUpperCase();
        if (code === 'AETHERIA2026') {
          this.appliedDiscount = 20;
          this.couponCode = code;
          window.aetheriaApp.showToast('Coupon "AETHERIA2026" applied! 20% OFF!');
          this.renderCheckoutSummary();
        } else {
          window.aetheriaApp.showToast('Invalid promo code. Try "AETHERIA2026"');
        }
      });
    }
  }

  initFormSubmit() {
    const form = document.getElementById('checkout-form');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();

        if (window.aetheriaApp.cart.length === 0) {
          window.aetheriaApp.showToast('Your cart is empty!');
          return;
        }

        // Play victory sound
        window.aetheriaApp.playAudio('success');

        // Clear cart
        window.aetheriaApp.cart = [];
        window.aetheriaApp.saveCart();

        // Show Success Modal
        const successModal = document.getElementById('order-success-modal');
        if (successModal) {
          document.getElementById('order-id-display').textContent = `#AE-${Math.floor(100000 + Math.random() * 900000)}`;
          successModal.classList.add('open');
        }
      });
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.checkoutController = new CheckoutController();
});
