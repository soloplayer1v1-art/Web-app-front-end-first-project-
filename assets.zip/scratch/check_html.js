const fs = require('fs');
const glob = ['index.html', 'catalog.html', 'product.html', 'checkout.html', 'about.html'];

glob.forEach(file => {
  const content = fs.readFileSync(file, 'utf8');
  // Check for basic unclosed tags
  const openTags = (content.match(/<[a-zA-Z0-9]+(?:\s+[^>]*)?>/g) || []).map(t => t.match(/<([a-zA-Z0-9]+)/)[1]);
  const closeTags = (content.match(/<\/[a-zA-Z0-9]+>/g) || []).map(t => t.match(/<\/([a-zA-Z0-9]+)/)[1]);
  
  const voidElements = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr', '!doctype', 'option']);
  
  const counts = {};
  openTags.forEach(t => {
    const lower = t.toLowerCase();
    if (!voidElements.has(lower)) {
      counts[lower] = (counts[lower] || 0) + 1;
    }
  });
  closeTags.forEach(t => {
    const lower = t.toLowerCase();
    counts[lower] = (counts[lower] || 0) - 1;
  });

  console.log(`--- Checking ${file} ---`);
  let hasErrors = false;
  for (const [tag, count] of Object.entries(counts)) {
    if (count !== 0) {
      console.error(`Mismatch tag <${tag}>: offset ${count}`);
      hasErrors = true;
    }
  }
  if (!hasErrors) {
    console.log(`HTML structure clean!`);
  }
});
