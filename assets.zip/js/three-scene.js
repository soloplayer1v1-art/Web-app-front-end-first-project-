/* ==========================================================================
   GAMER STORE 3D - Three.js WebGL Engine & Procedural 3D Models
   ========================================================================== */

class Aetheria3DEngine {
  constructor(canvasId, options = {}) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;

    this.options = Object.assign({
      autoRotate: true,
      enableZoom: true,
      cameraZ: 5,
      modelType: 'headphones',
      backgroundColor: null
    }, options);

    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.controls = null;
    this.mainModelGroup = null;
    this.subParts = {};
    this.isExploded = false;
    this.wireframeMode = false;
    this.currentColor = 0x00f3ff;
    this.rotorsToAnimate = [];

    this.init();
  }

  init() {
    this.scene = new THREE.Scene();

    const aspect = this.canvas.clientWidth / this.canvas.clientHeight;
    this.camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 100);
    this.camera.position.set(0, 0, this.options.cameraZ);

    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      alpha: true
    });
    this.renderer.setSize(this.canvas.clientWidth, this.canvas.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;

    this.setupLighting();
    this.loadModel(this.options.modelType);

    if (typeof THREE.OrbitControls !== 'undefined') {
      this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
      this.controls.enableDamping = true;
      this.controls.dampingFactor = 0.05;
      this.controls.autoRotate = this.options.autoRotate;
      this.controls.autoRotateSpeed = 1.5;
      this.controls.enableZoom = this.options.enableZoom;
    }

    window.addEventListener('resize', () => this.onWindowResize());
    this.animate();
  }

  setupLighting() {
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0x00f3ff, 2.0);
    keyLight.position.set(5, 5, 5);
    this.scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xff0055, 1.5);
    fillLight.position.set(-5, -3, -4);
    this.scene.add(fillLight);

    this.centerPointLight = new THREE.PointLight(0x00f3ff, 1.5, 10);
    this.centerPointLight.position.set(0, 0, 2);
    this.scene.add(this.centerPointLight);
  }

  loadModel(modelType) {
    if (this.mainModelGroup) {
      this.scene.remove(this.mainModelGroup);
    }

    this.mainModelGroup = new THREE.Group();
    this.subParts = {};
    this.rotorsToAnimate = [];

    switch (modelType) {
      case 'headphones':
        this.buildHeadphones();
        break;
      case 'visor':
        this.buildVisor();
        break;
      case 'ring':
        this.buildRing();
        break;
      case 'drone':
        this.buildDrone();
        break;
      case 'watch':
        this.buildWatch();
        break;
      case 'keyboard':
        this.buildKeyboard();
        break;
      case 'mouse':
        this.buildMouse();
        break;
      case 'powerbank':
        this.buildPowerbank();
        break;
      case 'core':
        this.buildCyberCore();
        break;
      default:
        this.buildHeadphones();
    }

    this.scene.add(this.mainModelGroup);
  }

  // --- MODEL 1: Headset ---
  buildHeadphones() {
    const group = this.mainModelGroup;
    this.subParts = { earcups: [], headband: null, accentRings: [] };

    const metallicMat = new THREE.MeshStandardMaterial({ color: 0x111625, metalness: 0.85, roughness: 0.2 });
    const glowMat = new THREE.MeshStandardMaterial({ color: this.currentColor, emissive: this.currentColor, emissiveIntensity: 0.8, roughness: 0.1 });
    const cushionMat = new THREE.MeshStandardMaterial({ color: 0x05070d, roughness: 0.9 });

    const headbandGeo = new THREE.TorusGeometry(1.2, 0.08, 16, 64, Math.PI * 1.1);
    const headbandMesh = new THREE.Mesh(headbandGeo, metallicMat);
    headbandMesh.rotation.z = -Math.PI * 0.55;
    headbandMesh.position.y = 0.4;
    group.add(headbandMesh);
    this.subParts.headband = headbandMesh;

    [-1.25, 1.25].forEach((xPos, idx) => {
      const earcupGroup = new THREE.Group();
      earcupGroup.position.set(xPos, -0.2, 0);

      const shellGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.3, 32);
      const shellMesh = new THREE.Mesh(shellGeo, metallicMat);
      shellMesh.rotation.z = Math.PI / 2;
      earcupGroup.add(shellMesh);

      const cushionGeo = new THREE.TorusGeometry(0.45, 0.1, 16, 32);
      const cushionMesh = new THREE.Mesh(cushionGeo, cushionMat);
      cushionMesh.rotation.y = Math.PI / 2;
      cushionMesh.position.x = idx === 0 ? 0.12 : -0.12;
      earcupGroup.add(cushionMesh);

      const ledGeo = new THREE.TorusGeometry(0.5, 0.02, 16, 32);
      const ledMesh = new THREE.Mesh(ledGeo, glowMat);
      ledMesh.rotation.y = Math.PI / 2;
      earcupGroup.add(ledMesh);
      this.subParts.accentRings.push(ledMesh);

      group.add(earcupGroup);
      this.subParts.earcups.push(earcupGroup);
    });

    group.position.y = 0.1;
  }

  // --- MODEL 2: Cyber Visor ---
  buildVisor() {
    const group = this.mainModelGroup;

    const frameMat = new THREE.MeshStandardMaterial({ color: 0x0c101c, metalness: 0.9, roughness: 0.15 });
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: this.currentColor, transmission: 0.6, opacity: 0.85, transparent: true, roughness: 0.1, ior: 1.5, reflectivity: 0.9
    });

    const shieldGeo = new THREE.CylinderGeometry(1.3, 1.3, 0.8, 32, 1, true, -Math.PI * 0.4, Math.PI * 0.8);
    const shieldMesh = new THREE.Mesh(shieldGeo, glassMat);
    shieldMesh.rotation.y = Math.PI;
    group.add(shieldMesh);

    const railGeo = new THREE.TorusGeometry(1.32, 0.05, 16, 64, Math.PI * 0.85);
    const railMesh = new THREE.Mesh(railGeo, frameMat);
    railMesh.rotation.x = Math.PI / 2;
    railMesh.rotation.z = -Math.PI * 0.425;
    railMesh.position.y = 0.4;
    group.add(railMesh);

    [-1.25, 1.25].forEach(x => {
      const armGeo = new THREE.BoxGeometry(0.1, 0.1, 1.4);
      const armMesh = new THREE.Mesh(armGeo, frameMat);
      armMesh.position.set(x, 0.3, -0.6);
      group.add(armMesh);
    });
  }

  // --- MODEL 3: Quantum Smart Ring ---
  buildRing() {
    const group = this.mainModelGroup;
    const ringMat = new THREE.MeshStandardMaterial({ color: 0x1a233a, metalness: 0.95, roughness: 0.1 });
    const coreGlowMat = new THREE.MeshStandardMaterial({ color: this.currentColor, emissive: this.currentColor, emissiveIntensity: 1.2 });

    const ringGeo = new THREE.TorusGeometry(1.2, 0.25, 32, 64);
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    group.add(ringMesh);

    const gemGeo = new THREE.OctahedronGeometry(0.4, 2);
    this.floatingGem = new THREE.Mesh(gemGeo, coreGlowMat);
    group.add(this.floatingGem);
  }

  // --- MODEL 4: Cyber Drone ---
  buildDrone() {
    const group = this.mainModelGroup;
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x090e1a, metalness: 0.9, roughness: 0.2 });
    const accentMat = new THREE.MeshStandardMaterial({ color: this.currentColor, emissive: this.currentColor, emissiveIntensity: 0.9 });

    const podGeo = new THREE.SphereGeometry(0.6, 32, 16);
    podGeo.scale(1, 0.4, 1);
    const podMesh = new THREE.Mesh(podGeo, bodyMat);
    group.add(podMesh);

    const angles = [Math.PI / 4, 3 * Math.PI / 4, 5 * Math.PI / 4, 7 * Math.PI / 4];
    angles.forEach(angle => {
      const armGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.4);
      const armMesh = new THREE.Mesh(armGeo, bodyMat);
      armMesh.rotation.z = Math.PI / 2;
      armMesh.rotation.y = angle;
      group.add(armMesh);

      const motorX = Math.cos(angle) * 0.7;
      const motorZ = Math.sin(angle) * 0.7;

      const bladeGeo = new THREE.BoxGeometry(0.7, 0.01, 0.06);
      const bladeMesh = new THREE.Mesh(bladeGeo, accentMat);
      bladeMesh.position.set(motorX, 0.1, motorZ);
      group.add(bladeMesh);

      this.rotorsToAnimate.push(bladeMesh);
    });
  }

  // --- MODEL 5: Quantum Watch ---
  buildWatch() {
    const group = this.mainModelGroup;
    const caseMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.9, roughness: 0.1 });
    const bezelMat = new THREE.MeshStandardMaterial({ color: this.currentColor, emissive: this.currentColor, emissiveIntensity: 0.8 });
    const screenMat = new THREE.MeshStandardMaterial({ color: 0x04060c, roughness: 0.1 });

    const caseGeo = new THREE.CylinderGeometry(1.1, 1.1, 0.3, 32);
    const caseMesh = new THREE.Mesh(caseGeo, caseMat);
    caseMesh.rotation.x = Math.PI / 2;
    group.add(caseMesh);

    const bezelGeo = new THREE.TorusGeometry(1.15, 0.05, 16, 64);
    const bezelMesh = new THREE.Mesh(bezelGeo, bezelMat);
    group.add(bezelMesh);

    const screenGeo = new THREE.CircleGeometry(0.95, 32);
    const screenMesh = new THREE.Mesh(screenGeo, screenMat);
    screenMesh.position.z = 0.16;
    group.add(screenMesh);

    const hudGeo = new THREE.TorusGeometry(0.7, 0.02, 16, 32);
    this.floatingGem = new THREE.Mesh(hudGeo, bezelMat);
    this.floatingGem.position.z = 0.17;
    group.add(this.floatingGem);
  }

  // --- NEW MODEL 6: Mechanical Cyber Keyboard ---
  buildKeyboard() {
    const group = this.mainModelGroup;
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x0a0e1a, metalness: 0.8, roughness: 0.2 });
    const keyMat = new THREE.MeshStandardMaterial({ color: 0x162036, roughness: 0.3 });
    const rgbMat = new THREE.MeshStandardMaterial({ color: this.currentColor, emissive: this.currentColor, emissiveIntensity: 0.9 });

    // Keyboard Base Plate
    const baseGeo = new THREE.BoxGeometry(2.4, 0.15, 1.1);
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    group.add(baseMesh);

    // Glowing Underglow Rail
    const railGeo = new THREE.BoxGeometry(2.45, 0.02, 1.15);
    const railMesh = new THREE.Mesh(railGeo, rgbMat);
    railMesh.position.y = -0.07;
    group.add(railMesh);

    // Keycaps Matrix Grid
    const rows = 4;
    const cols = 10;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const keyGeo = new THREE.BoxGeometry(0.18, 0.1, 0.18);
        const isAccent = (r === 0 && c === 0) || (r === 3 && c === 4);
        const mesh = new THREE.Mesh(keyGeo, isAccent ? rgbMat : keyMat);
        mesh.position.set(-1.0 + c * 0.22, 0.12, -0.35 + r * 0.22);
        group.add(mesh);
      }
    }

    group.rotation.x = Math.PI / 6;
  }

  // --- NEW MODEL 7: Wireless Cyber Mouse ---
  buildMouse() {
    const group = this.mainModelGroup;
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x090e18, metalness: 0.85, roughness: 0.15 });
    const ledMat = new THREE.MeshStandardMaterial({ color: this.currentColor, emissive: this.currentColor, emissiveIntensity: 1.0 });

    // Ergonomic Body Shell
    const shellGeo = new THREE.SphereGeometry(1.0, 32, 16);
    shellGeo.scale(0.8, 0.5, 1.4);
    const shellMesh = new THREE.Mesh(shellGeo, bodyMat);
    group.add(shellMesh);

    // Scroll Wheel
    const wheelGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.1, 24);
    const wheelMesh = new THREE.Mesh(wheelGeo, ledMat);
    wheelMesh.rotation.z = Math.PI / 2;
    wheelMesh.position.set(0, 0.28, -0.6);
    group.add(wheelMesh);

    // LED Spine Light Strip
    const spineGeo = new THREE.TorusGeometry(0.72, 0.02, 16, 32, Math.PI * 0.8);
    const spineMesh = new THREE.Mesh(spineGeo, ledMat);
    spineMesh.rotation.x = Math.PI / 2;
    spineMesh.position.y = 0.1;
    group.add(spineMesh);

    group.rotation.x = Math.PI / 8;
  }

  // --- NEW MODEL 8: Cyber Powerbank ---
  buildPowerbank() {
    const group = this.mainModelGroup;
    const casingMat = new THREE.MeshStandardMaterial({ color: 0x0b1326, metalness: 0.9, roughness: 0.1 });
    const oledMat = new THREE.MeshStandardMaterial({ color: 0x000000, roughness: 0.05 });
    const portMat = new THREE.MeshStandardMaterial({ color: this.currentColor, emissive: this.currentColor, emissiveIntensity: 1.1 });

    // Powerbank Main Casing
    const caseGeo = new THREE.BoxGeometry(1.2, 2.2, 0.35);
    const caseMesh = new THREE.Mesh(caseGeo, casingMat);
    group.add(caseMesh);

    // OLED Readout Screen
    const screenGeo = new THREE.PlaneGeometry(0.7, 0.35);
    const screenMesh = new THREE.Mesh(screenGeo, oledMat);
    screenMesh.position.set(0, 0.6, 0.18);
    group.add(screenMesh);

    // Glowing Percentage Ring inside OLED
    const ringGeo = new THREE.TorusGeometry(0.1, 0.015, 16, 32);
    const ringMesh = new THREE.Mesh(ringGeo, portMat);
    ringMesh.position.set(0, 0.6, 0.19);
    group.add(ringMesh);

    // Dual USB-C Ports Top
    [-0.25, 0.25].forEach(x => {
      const portGeo = new THREE.BoxGeometry(0.2, 0.04, 0.1);
      const portMesh = new THREE.Mesh(portGeo, portMat);
      portMesh.position.set(x, 1.11, 0);
      group.add(portMesh);
    });

    group.rotation.z = -Math.PI / 12;
  }

  // --- MODEL BUILDER 9: Cyber Core ---
  buildCyberCore() {
    const group = this.mainModelGroup;

    const wireMat = new THREE.MeshStandardMaterial({
      color: this.currentColor, wireframe: true, emissive: this.currentColor, emissiveIntensity: 0.5
    });

    const icoGeo = new THREE.IcosahedronGeometry(1.2, 1);
    const icoMesh = new THREE.Mesh(icoGeo, wireMat);
    group.add(icoMesh);
    this.coreMesh = icoMesh;

    const innerGeo = new THREE.OctahedronGeometry(0.6, 0);
    const innerMat = new THREE.MeshStandardMaterial({ color: 0xff0055, emissive: 0xff0055, emissiveIntensity: 1 });
    this.innerCore = new THREE.Mesh(innerGeo, innerMat);
    group.add(this.innerCore);
  }

  setColor(hexColor) {
    this.currentColor = hexColor;
    if (this.centerPointLight) this.centerPointLight.color.setHex(hexColor);

    this.mainModelGroup.traverse(child => {
      if (child.isMesh && child.material) {
        if (child.material.emissive && child.material.emissive.getHex() !== 0xff0055) {
          child.material.color.setHex(hexColor);
          child.material.emissive.setHex(hexColor);
        }
      }
    });
  }

  toggleExplode(explodeState) {
    this.isExploded = explodeState;
    if (this.subParts.earcups && this.subParts.earcups.length === 2) {
      const targetLeftX = explodeState ? -1.8 : -1.25;
      const targetRightX = explodeState ? 1.8 : 1.25;
      const targetHeadbandY = explodeState ? 0.7 : 0.4;

      if (typeof gsap !== 'undefined') {
        gsap.to(this.subParts.earcups[0].position, { x: targetLeftX, duration: 0.6 });
        gsap.to(this.subParts.earcups[1].position, { x: targetRightX, duration: 0.6 });
        gsap.to(this.subParts.headband.position, { y: targetHeadbandY, duration: 0.6 });
      } else {
        this.subParts.earcups[0].position.x = targetLeftX;
        this.subParts.earcups[1].position.x = targetRightX;
        this.subParts.headband.position.y = targetHeadbandY;
      }
    }
  }

  toggleWireframe(wireframeState) {
    this.wireframeMode = wireframeState;
    this.mainModelGroup.traverse(child => {
      if (child.isMesh && child.material) {
        child.material.wireframe = wireframeState;
      }
    });
  }

  onWindowResize() {
    if (!this.canvas || !this.camera || !this.renderer) return;
    const width = this.canvas.clientWidth;
    const height = this.canvas.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  animate() {
    requestAnimationFrame(() => this.animate());

    if (this.controls) this.controls.update();

    if (this.floatingGem) {
      this.floatingGem.rotation.y += 0.02;
      this.floatingGem.rotation.x += 0.01;
    }

    if (this.rotorsToAnimate.length) {
      this.rotorsToAnimate.forEach(blade => {
        blade.rotation.y += 0.3;
      });
    }

    if (this.coreMesh) {
      this.coreMesh.rotation.y += 0.005;
      this.coreMesh.rotation.x += 0.003;
      this.innerCore.rotation.y -= 0.02;
    }

    this.renderer.render(this.scene, this.camera);
  }
}

window.Aetheria3DEngine = Aetheria3DEngine;
