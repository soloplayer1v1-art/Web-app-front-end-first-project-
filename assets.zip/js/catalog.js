/* ==========================================================================
   GAMER STORE 3D - Catalog & Product Store Logic
   ========================================================================== */

const AETHERIA_PRODUCTS = [
  {
    id: 'headphones-x1',
    name: 'AETHERIA Spatial X1',
    category: 'audio',
    categoryLabel: 'Spatial Audio',
    price: 399,
    rating: 4.9,
    reviewsCount: 128,
    image: 'assets/images/headphones.jpg',
    modelType: 'headphones',
    description: 'Next-gen active noise-canceling spatial audio headset with 3D sonic hologram technology, dual graphene drivers, and titanium headband.',
    badge: 'Best Seller',
    specs: { Driver: '40mm Graphene', Latency: '< 5ms', Battery: '45 Hours', Audio: '96kHz / 24-bit' }
  },
  {
    id: 'visor-v2',
    name: 'NEXUS Cyber Visor V2',
    category: 'visors',
    categoryLabel: 'Cyber Visors',
    price: 649,
    rating: 4.8,
    reviewsCount: 94,
    image: 'assets/images/visor.jpg',
    modelType: 'visor',
    description: 'Transparent Micro-OLED AR visor featuring 8K retinal resolution, neural eye-tracking HUD, and real-time spatial depth translation.',
    badge: 'New Tech',
    specs: { Resolution: '8K Micro-OLED', FieldOfView: '120°', Weight: '180g', RefreshRate: '120Hz' }
  },
  {
    id: 'ring-q1',
    name: 'QUANTUM Smart Ring Q1',
    category: 'rings',
    categoryLabel: 'Neural Rings',
    price: 289,
    rating: 4.7,
    reviewsCount: 210,
    image: 'assets/images/ring.jpg',
    modelType: 'ring',
    description: 'Forged Grade 5 titanium smart ring with biometric haptic engine, gesture air-control, and continuous neural telemetry.',
    badge: 'Popular',
    specs: { Material: 'Grade 5 Titanium', Battery: '7 Days', Waterproof: '100m Submersed', Sensors: 'Sub-dermal Optical' }
  },
  {
    id: 'keyboard-cyber',
    name: 'CYBER BLADE Mechanical Keyboard',
    category: 'peripherals',
    categoryLabel: 'Gaming Peripherals',
    price: 199,
    rating: 4.95,
    reviewsCount: 312,
    image: 'assets/images/keyboard.jpg',
    modelType: 'keyboard',
    description: 'Hot-swappable magnetic hall-effect switch keyboard with per-key RGB backlighting, aircraft aluminum top frame, and 8,000Hz polling rate.',
    badge: 'Top Choice',
    specs: { Switches: 'Hall-Effect Magnetic', PollingRate: '8000Hz', Keycaps: 'PBT Double-shot', Connectivity: 'Tri-Mode Wireless' }
  },
  {
    id: 'mouse-apex',
    name: 'APEX WIRELESS Cyber Mouse',
    category: 'peripherals',
    categoryLabel: 'Gaming Peripherals',
    price: 149,
    rating: 4.9,
    reviewsCount: 245,
    image: 'assets/images/mouse.jpg',
    modelType: 'mouse',
    description: 'Ultra-lightweight 52g wireless esports gaming mouse with 36,000 DPI PAW3395 optical sensor and 90-hour battery life.',
    badge: 'Esports Pro',
    specs: { Weight: '52 Grams', Sensor: '36,000 DPI Optical', Battery: '90 Hours', Switches: 'Optical 100M Clicks' }
  },
  {
    id: 'powerbank-titan',
    name: 'TITAN PLASMA Powerbank 50,000mAh',
    category: 'accessories',
    categoryLabel: 'Power & Accessories',
    price: 129,
    rating: 4.85,
    reviewsCount: 184,
    image: 'assets/images/ring.jpg',
    modelType: 'powerbank',
    description: 'Cyberpunk transparent high-capacity powerbank with 140W GaN ultra-fast charging, digital OLED status display, and dual USB-C ports.',
    badge: 'High Power',
    specs: { Capacity: '50,000 mAh', Output: '140W Fast GaN', Display: 'Color OLED', Ports: '2x Type-C + 1x USB-A' }
  },
  {
    id: 'drone-r4',
    name: 'AETHERIA Recon Drone R4',
    category: 'drones',
    categoryLabel: 'Autonomous Drones',
    price: 899,
    rating: 4.95,
    reviewsCount: 67,
    image: 'assets/images/headphones.jpg',
    modelType: 'drone',
    description: 'Compact stealth quadcopter drone equipped with 4K LiDAR obstacle avoidance, 360° AI tracking, and silent ion propellers.',
    badge: 'Pro Spec',
    specs: { Range: '15 Kilometers', MaxSpeed: '95 km/h', FlightTime: '38 Mins', Cam: '4K HDR LiDAR' }
  },
  {
    id: 'watch-chrono',
    name: 'CHRONO Quantum Smart Watch',
    category: 'wearables',
    categoryLabel: 'Smart Wearables',
    price: 499,
    rating: 4.88,
    reviewsCount: 176,
    image: 'assets/images/ring.jpg',
    modelType: 'watch',
    description: 'Futuristic smartwatch with rotating glowing digital HUD bezel, biometric health scanner, and holographic notification stream.',
    badge: 'New Release',
    specs: { Display: '1.9" Sapphire OLED', Water: '20 ATM', Battery: '14 Days', Chip: 'Quantum Q2' }
  },
  {
    id: 'visor-hologram',
    name: 'ORBIT Holographic VR Goggles',
    category: 'visors',
    categoryLabel: 'Cyber Visors',
    price: 599,
    rating: 4.7,
    reviewsCount: 89,
    image: 'assets/images/visor.jpg',
    modelType: 'visor',
    description: 'Ultra-wide FOV virtual reality optics with electrochromic dimming visor glass and hand gesture spatial passthrough.',
    badge: 'Immersive',
    specs: { Resolution: '4K Per Eye', Tracking: 'Inside-Out 6DOF', Optics: 'Pancake 2.0', Weight: '210g' }
  },
  {
    id: 'keyboard-optix',
    name: 'OPTIX Optical Rapid Trigger Keyboard',
    category: 'peripherals',
    categoryLabel: 'Gaming Peripherals',
    price: 229,
    rating: 4.92,
    reviewsCount: 96,
    image: 'assets/images/keyboard.jpg',
    modelType: 'keyboard',
    description: '65% compact tournament keyboard featuring rapid trigger technology (0.1mm actuation) and acoustic dampening silicone pads.',
    badge: 'Rapid Trigger',
    specs: { Actuation: '0.1mm - 4.0mm Adjustable', Layout: '65% Compact', Plate: 'Brass Plate', Latency: '0.12ms' }
  },
  {
    id: 'mouse-stealth',
    name: 'PHANTOM Ultra-Light 49g Gaming Mouse',
    category: 'peripherals',
    categoryLabel: 'Gaming Peripherals',
    price: 169,
    rating: 4.89,
    reviewsCount: 142,
    image: 'assets/images/mouse.jpg',
    modelType: 'mouse',
    description: 'Magnesium alloy honeycomb skeleton wireless gaming mouse weighing only 49 grams with 8K Hz wireless receiver.',
    badge: 'Magnesium 49g',
    specs: { Shell: 'Magnesium Alloy', Polling: '8000Hz Wireless', Weight: '49 Grams', Feet: '100% PTFE' }
  },
  {
    id: 'headphones-pro',
    name: 'GAMER Pulse 3D Planar Headset',
    category: 'audio',
    categoryLabel: 'Spatial Audio',
    price: 449,
    rating: 4.95,
    reviewsCount: 210,
    image: 'assets/images/headphones.jpg',
    modelType: 'headphones',
    description: 'Tournament esports headset equipped with planar magnetic transducers, detachable AI noise beamforming mic, and custom RGB ring.',
    badge: 'Esports Pro',
    specs: { Transducer: 'Planar Magnetic', Mic: 'AI Noise Canceling', Battery: '50 Hours', Audio: '192kHz Spatial' }
  },
  {
    id: 'ring-apex',
    name: 'APEX Air-Mouse Gesture Ring',
    category: 'rings',
    categoryLabel: 'Neural Rings',
    price: 319,
    rating: 4.8,
    reviewsCount: 114,
    image: 'assets/images/ring.jpg',
    modelType: 'ring',
    description: 'Esports air-mouse ring with micro-gyroscope 9-axis tracking for zero-latency gesture shortcuts in VR games.',
    badge: 'Air Mouse',
    specs: { Sensors: '9-Axis Gyro', Latency: '< 1ms', Haptics: 'Linear Micro-Motor', Weight: '5.5g' }
  },
  {
    id: 'drone-stealth',
    name: 'PHANTOM Stealth Thermal Drone X',
    category: 'drones',
    categoryLabel: 'Autonomous Drones',
    price: 1199,
    rating: 5.0,
    reviewsCount: 38,
    image: 'assets/images/headphones.jpg',
    modelType: 'drone',
    description: 'Flagship carbon-fiber autonomous reconnaissance drone featuring night-vision thermal imaging and automatic return dock.',
    badge: 'Ultimate',
    specs: { Frame: 'Full Carbon Fiber', Camera: 'Thermal 8K', Range: '25 Kilometers', Battery: '45 Mins' }
  },
  {
    id: 'powerbank-mini',
    name: 'NEBULA MagCharge Quantum Power Puck',
    category: 'accessories',
    categoryLabel: 'Power & Accessories',
    price: 89,
    rating: 4.78,
    reviewsCount: 155,
    image: 'assets/images/visor.jpg',
    modelType: 'powerbank',
    description: 'Magnetic snap wireless power puck with active cooling fan, glowing LED aura ring, and 15W Qi2 fast charging.',
    badge: 'Magnetic Qi2',
    specs: { Charging: '15W Wireless Qi2', Cooling: 'Active Fan', Attachment: 'N52 Neodymium Magnets', Capacity: '10,000 mAh' }
  }
];

class CatalogController {
  constructor() {
    this.products = AETHERIA_PRODUCTS;
    this.currentCategory = 'all';
    this.currentSort = 'featured';
    this.searchQuery = '';
    this.maxPrice = 1200;

    this.gridContainer = document.getElementById('catalog-products-grid');
    if (!this.gridContainer) return;

    this.initFilters();
    this.render();
    this.initModal();
  }

  initFilters() {
    const categoryBtns = document.querySelectorAll('.category-tab');
    categoryBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        categoryBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.currentCategory = btn.dataset.category || 'all';
        this.render();
      });
    });

    const searchInput = document.getElementById('catalog-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.searchQuery = e.target.value.toLowerCase();
        this.render();
      });
    }

    const sortSelect = document.getElementById('catalog-sort-select');
    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        this.currentSort = e.target.value;
        this.render();
      });
    }

    const priceRange = document.getElementById('catalog-price-range');
    const priceDisplay = document.getElementById('price-range-display');
    if (priceRange && priceDisplay) {
      priceRange.addEventListener('input', (e) => {
        this.maxPrice = parseFloat(e.target.value);
        priceDisplay.textContent = `$${this.maxPrice}`;
        this.render();
      });
    }
  }

  getFilteredProducts() {
    return this.products.filter(item => {
      const matchesCategory = this.currentCategory === 'all' || item.category === this.currentCategory;
      const matchesSearch = item.name.toLowerCase().includes(this.searchQuery) || item.description.toLowerCase().includes(this.searchQuery);
      const matchesPrice = item.price <= this.maxPrice;
      return matchesCategory && matchesSearch && matchesPrice;
    }).sort((a, b) => {
      if (this.currentSort === 'price-low') return a.price - b.price;
      if (this.currentSort === 'price-high') return b.price - a.price;
      if (this.currentSort === 'rating') return b.rating - a.rating;
      return 0;
    });
  }

  render() {
    const list = this.getFilteredProducts();

    if (list.length === 0) {
      this.gridContainer.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 4rem 1rem;">
          <h3 style="color: var(--text-muted);">No Cyber Hardware Found</h3>
          <p style="margin-top: 0.5rem; font-size: 0.9rem;">Try adjusting your category filter or search keywords.</p>
        </div>
      `;
      return;
    }

    this.gridContainer.innerHTML = list.map(item => `
      <div class="glass-card product-card glass-card-shimmer" data-id="${item.id}">
        <div class="product-card-thumb">
          <span class="badge-neon" style="position: absolute; top: 1rem; left: 1rem; z-index: 2;">${item.badge}</span>
          <img src="${item.image}" alt="${item.name}" loading="lazy" />
        </div>
        <div class="product-card-body">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <span style="font-size: 0.75rem; color: var(--primary-cyan); font-family: var(--font-heading); text-transform: uppercase;">${item.categoryLabel}</span>
            <span style="font-size: 0.85rem; color: var(--accent-gold);">★ ${item.rating}</span>
          </div>
          <h3 class="product-title">${item.name}</h3>
          <p class="product-desc">${item.description}</p>
          <div class="product-card-footer">
            <span class="product-price">$${item.price}</span>
            <div style="display: flex; gap: 0.5rem;">
              <button class="btn-cyber btn-cyber-secondary btn-quick-view" data-id="${item.id}" style="padding: 0.5rem 0.8rem; font-size: 0.75rem;">
                3D View
              </button>
              <button class="btn-cyber btn-add-cart" data-id="${item.id}" style="padding: 0.5rem 1rem; font-size: 0.75rem;">
                + Cart
              </button>
            </div>
          </div>
        </div>
      </div>
    `).join('');

    this.gridContainer.querySelectorAll('.btn-add-cart').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        const prod = this.products.find(p => p.id === id);
        if (prod && window.aetheriaApp) {
          window.aetheriaApp.addToCart(prod);
        }
      });
    });

    this.gridContainer.querySelectorAll('.btn-quick-view').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        this.openQuickView(id);
      });
    });
  }

  initModal() {
    this.modalOverlay = document.getElementById('quickview-modal-overlay');
    this.modalCloseBtn = document.getElementById('quickview-modal-close');
    if (this.modalCloseBtn) {
      this.modalCloseBtn.addEventListener('click', () => this.closeQuickView());
    }
    if (this.modalOverlay) {
      this.modalOverlay.addEventListener('click', (e) => {
        if (e.target === this.modalOverlay) this.closeQuickView();
      });
    }
  }

  openQuickView(productId) {
    const prod = this.products.find(p => p.id === productId);
    if (!prod || !this.modalOverlay) return;

    document.getElementById('quickview-title').textContent = prod.name;
    document.getElementById('quickview-price').textContent = `$${prod.price}`;
    document.getElementById('quickview-desc').textContent = prod.description;
    
    const specsContainer = document.getElementById('quickview-specs');
    if (specsContainer && prod.specs) {
      specsContainer.innerHTML = Object.entries(prod.specs).map(([key, val]) => `
        <div style="background: rgba(255,255,255,0.04); padding: 0.5rem 0.8rem; border-radius: 6px; font-size: 0.8rem;">
          <span style="color: var(--text-muted); display: block;">${key}</span>
          <strong style="color: var(--primary-cyan);">${val}</strong>
        </div>
      `).join('');
    }

    const modalAddBtn = document.getElementById('quickview-add-btn');
    if (modalAddBtn) {
      modalAddBtn.onclick = () => {
        window.aetheriaApp.addToCart(prod);
        this.closeQuickView();
      };
    }

    const configBtn = document.getElementById('quickview-config-btn');
    if (configBtn) {
      configBtn.onclick = () => {
        window.location.href = `product.html?id=${prod.id}`;
      };
    }

    this.modalOverlay.classList.add('open');

    const modalCanvas = document.getElementById('modal-3d-canvas');
    if (modalCanvas && window.Aetheria3DEngine) {
      if (this.modal3DEngine) {
        this.modal3DEngine.loadModel(prod.modelType);
      } else {
        this.modal3DEngine = new window.Aetheria3DEngine('modal-3d-canvas', {
          modelType: prod.modelType,
          cameraZ: 4.5
        });
      }
    }
  }

  closeQuickView() {
    if (this.modalOverlay) this.modalOverlay.classList.remove('open');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.catalogController = new CatalogController();
});
